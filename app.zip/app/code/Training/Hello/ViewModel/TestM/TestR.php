<?php 
namespace Training\Hello\ViewModel\TestM;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class TestR implements ArgumentInterface{

    public function getTitle()

    {

      return 'Pwede na';

    }
}

?>